function sprawdz_podstawowe_ustawienia()	{
	var hours_in_day_work = document.getElementById('hours_in_day_work').value;
	var money_on_hour = document.getElementById('money_on_hour').value;
	var days_in_work = document.getElementById('days_in_work').value;
	var hours_in_work = days_in_work * hours_in_day_work;
	var my_money = money_on_hour * hours_in_work;
	alert(my_money);
}

function PokazUkryjTekst(polecenie,id) {
    var PrzyciskPokaz = document.getElementById('PrzyciskPokaz_' + id);
    var PrzyciskUkryj = document.getElementById('PrzyciskUkryj_' + id);
    var TrescSkrocona = document.getElementById('TrescSkrocona_' + id);
    var TrescPelna = document.getElementById('TrescPelna_' + id);
	if (polecenie == 'Pokaz') {
		PrzyciskPokaz.style.display = 'none';
		PrzyciskUkryj.style.display = 'block';
		TrescSkrocona.style.display = 'none';
		TrescPelna.style.display = 'block';
	} 
	else if (polecenie == 'Ukryj') {
		PrzyciskPokaz.style.display = 'block';
		PrzyciskUkryj.style.display = 'none';
		TrescSkrocona.style.display = 'block';
		TrescPelna.style.display = 'none';
	}
}

function test()	{
var test = document.getElementById('test').value;
var test2 = document.getElementById('test2').value;
var test3 = test + test2;
alert(test3);
}