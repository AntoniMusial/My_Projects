var java_frameworks = [
	'spring',
	'hibernate',
	'play',
	'dropwizard',
	'gwt',
	'jsf',
	'vaadin',
	'blade',
	'grails',
	'struts',
	'jhipster',
	'mybatis',
	'primefaces',
	'spark',
	'tapestry',
	'vertx',
	'wicket',
];

let answer = '';
let maxWrong = 7;
let mistakes = 0;
let guessed = [];
let wordStatus = null;

function randomWord() {
	answer = java_frameworks[Math.floor(Math.random() * java_frameworks.length)];
}

function generateButtons() {
	let buttonsHTML = 'abcdefghijklmnopqrstuvwxyz'
		.split('')
		.map(
			(letter) =>
				`
        <button
          class="btn btn-lg btn-primary m-2"
          id='` +
				letter +
				`'
          onClick="handleGuess('` +
				letter +
				`')"
        >
          ` +
				letter +
				`
        </button>
      `
		)
		.join('');

	document.getElementById('keyboard').innerHTML = buttonsHTML;
}

function handleGuess(chosenLetter) {
	guessed.indexOf(chosenLetter) === -1 ? guessed.push(chosenLetter) : null;
	document.getElementById(chosenLetter).setAttribute('disabled', true); //litery nie będą się powtarzać id to litera zawarta w funkcji generateButtons

	if (answer.indexOf(chosenLetter) >= 0) {
		guessedWord(); //odnowi status liter
		checkIfGameWon();
	} else if (answer.indexOf(chosenLetter) === -1) {
		mistakes++;
		updateMistakes();
		checkIfGameLost();
		updateHangmanPicture();
	}
}

function updateHangmanPicture() {
	document.getElementById('hangmanPic').src = './img/wisielec' + mistakes + '.png';
}

function checkIfGameWon() {
	if (wordStatus === answer) {
		document.getElementById('keyboard').innerHTML = 'Wygrałeś!!!';
	}
}

function checkIfGameLost() {
	if (mistakes === maxWrong) {
		document.getElementById('wordSpotlight').innerHTML =
			'The answer was: ' + answer;
		document.getElementById('keyboard').innerHTML = 'Przegrałeś!!!';
	}
}

function guessedWord() {
	wordStatus = answer
		.split('')
		.map((letter) => (guessed.indexOf(letter) >= 0 ? letter : ' _ '))
		.join('');

	document.getElementById('wordSpotlight').innerHTML = wordStatus;
}

function updateMistakes() {
	document.getElementById('mistakes').innerHTML = mistakes;
}

function reset() {
	mistakes = 0;
	guessed = [];
	document.getElementById('hangmanPic').src = './img/wisielec/0.png';

	randomWord();
	guessedWord();
	updateMistakes();
	generateButtons();
}

document.getElementById('maxWrong').innerHTML = maxWrong;

randomWord();
generateButtons();
guessedWord();
